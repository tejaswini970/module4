package com.cg.webservice.lab1;

import java.util.HashMap;

import javax.jws.WebService;


import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

import com.cg.webservices.bean.Product;
import com.cg.webservices.staticdb.ProductDB;

@WebService
@SOAPBinding(style=Style.RPC)
public interface ProductServer {
	static HashMap<String, Product> productNameMap = ProductDB.getProductNameMap();
	
	public static  Product getPrice(String productName) {
		Product price = productNameMap.get(productName);
		return price;
	}

}
