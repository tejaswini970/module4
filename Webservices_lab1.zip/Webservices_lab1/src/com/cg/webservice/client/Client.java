package com.cg.webservice.client;

import java.net.URL;
import java.util.Scanner;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;




import com.cg.webservice.dao.ProductServer;

public class Client {

	public static void main(String[] args) throws Exception {
		URL url = new URL("http://localhost:9876/ps?wsdl");

		QName qname = new QName("http://lab1.webservice.cg.com/","ProductpriceService");
		
		Service service = Service.create(url, qname);
		
		ProductServer endPointIntf = service.getPort(ProductServer.class);
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter product Name");
		String productName= scanner.nextLine();
		System.out.println("price is "+endPointIntf.getPrice(productName));
		scanner.close();

	}

}
