package com.cg.webservices.staticdb;

import java.util.HashMap;


import com.cg.webservices.bean.Product;




/**
 * @author ssuggise
 *
 */
public class ProductDB {
	static HashMap<String, Product> productNameMap = getProductNameMap();
	
	static {
		if (productNameMap == null) {
			productNameMap = new HashMap<String, Product>();
			Product ipadPhone = new Product(1, "Ipad", 10000);
			Product samsungPhone = new Product(4, "Samsung", 20000);
			Product vivoPhone = new Product(3, "Vivo", 8000);
			Product miPhone = new Product(2, "Mi", 7000);

			productNameMap.put("Ipad", ipadPhone);
			productNameMap.put("Samsung", samsungPhone);
			productNameMap.put("Vivo", vivoPhone);
			productNameMap.put("Mi", miPhone);
		}

	}
	/**
	 * This is a getter method of HashMap
	 * @return HashMap<String, Product>
	 */
	
	public static HashMap<String, Product> getProductNameMap() {
		return productNameMap;
	}
}
