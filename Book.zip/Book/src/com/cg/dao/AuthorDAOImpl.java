package com.cg.dao;

import javax.persistence.EntityManager;

import com.cg.bean.Author;
import com.cg.exception.AuthorException;


public class AuthorDAOImpl implements AuthorDAO {
	
	
	private EntityManager entityManager;

	public AuthorDAOImpl() {
		entityManager = JPAUtil.getEntityManager();
	}
	
	@Override
	public int addAuthor(Author author) throws AuthorException {
		entityManager.persist(author);
		return author.getAuthor_id();
	}

	@Override
	public void commitTransaction() throws AuthorException{
		entityManager.getTransaction().commit();
		
	}

	@Override
	public void beginTransaction() throws AuthorException{
		entityManager.getTransaction().begin();
		
	}

}
