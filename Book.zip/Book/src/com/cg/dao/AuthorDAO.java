package com.cg.dao;

import com.cg.bean.Author;
import com.cg.exception.AuthorException;

public interface AuthorDAO {

	public abstract int addAuthor(Author author) throws AuthorException;
	
	public abstract void commitTransaction()throws AuthorException;

	public abstract void beginTransaction()throws AuthorException;
}
