package com.cg.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="author_tbl")


public class Author implements Serializable {
 
	/**
	 * 
	 */
	private static final long serialVersionUID = -142781908083526706L;

	@Id
	@GeneratedValue
	@Column(name="author_id")
	private int author_id;
	
	@Column(name="fname",length=10)
	private String fname;
	
	@Column(name="mname",length=10)
	private String mname;
	
	@Column(name="lname",length=10)
	private String lname;
	
	@Column(name="fname",length=10)
	private String phoneno;
	
	public int getAuthor_id() {
		return author_id;
	}
	public void setAuthor_id(int author_id) {
		this.author_id = author_id;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	public Author() {
		super();
	}
	public Author(int author_id, String fname, String mname, String lname,
			String phoneno) {
		super();
		this.author_id = author_id;
		this.fname = fname;
		this.mname = mname;
		this.lname = lname;
		this.phoneno = phoneno;
	}
	
}
