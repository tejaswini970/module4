package com.cg.exception;

public class AuthorException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3155034897592569217L;
   public AuthorException(String message)
   {
	   super(message);
   }
}
