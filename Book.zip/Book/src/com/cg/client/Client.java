package com.cg.client;

import com.cg.bean.Author;
import com.cg.exception.AuthorException;
import com.cg.service.AuthorService;
import com.cg.service.AuthorServiceImpl;

public class Client {

	public static void main(String[] args) {
		AuthorService authorservice=new AuthorServiceImpl();
		
		Author author=new Author();
		author.setFname("SAI");
		author.setMname("Tejaswini");
		author.setLname("Suggisetti");
		author.setPhoneno("9704405628");
		try {
			authorservice.addAuthor(author);
		} catch (AuthorException e) {
			System.out.println("Unable to add the author");
			
		}

	}

}
