package com.cg.service;

import com.cg.bean.Author;
import com.cg.dao.AuthorDAO;
import com.cg.exception.AuthorException;

public class AuthorServiceImpl implements AuthorService {
 private AuthorDAO dao;
	
	@Override
	public int addAuthor(Author author) throws AuthorException {
	
			dao.beginTransaction();
			dao.addAuthor(author);
			dao.commitTransaction();
			
		
		return author.getAuthor_id();
	}

}
