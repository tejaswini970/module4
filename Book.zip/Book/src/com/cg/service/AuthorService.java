package com.cg.service;

import com.cg.bean.Author;
import com.cg.exception.AuthorException;

public interface AuthorService {
	public abstract int addAuthor(Author author) throws AuthorException;
	
}
