package com.test;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

public class BPP implements BeanPostProcessor {

	@Override
	public Object postProcessAfterInitialization(Object obj, String name)
			throws BeansException {
		System.out.println("BPP AFTER INIT CALLER");
		return obj;
	}

	@Override
	public Object postProcessBeforeInitialization(Object obj, String name)
			throws BeansException {
	System.out.println("BPP BEFORE INIT CALLER");
		return obj;
	}

}
