package com.cg.webservices.staticdb;

import java.util.HashMap;



import com.cg.webservices.bean.Product;




/**
 * @author ssuggise
 *
 */
public class ProductDB {
	static HashMap<Integer, Product> productIdMap = getProductIdMap();
	
	static {
		if (productIdMap == null) {
			productIdMap = new HashMap<Integer, Product>();
			Product ipadPhone = new Product(1, "Ipad", 10000);
			Product samsungPhone = new Product(4, "Samsung", 20000);
			Product vivoPhone = new Product(3, "Vivo", 8000);
			Product miPhone = new Product(2, "Mi", 7000);

			productIdMap.put(1, ipadPhone);
			productIdMap.put(4, samsungPhone);
			productIdMap.put(3, vivoPhone);
			productIdMap.put(2, miPhone);
		}

	}
	/**
	 * This is a getter method of HashMap
	 * @return HashMap<String, Product>
	 */
	
	public static HashMap<Integer, Product> getProductIdMap() {
		return productIdMap;
	}
	
}
